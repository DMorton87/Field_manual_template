## 1 Live Host Enumeration

- [ ] Conduct a ping sweep of IP range
- [ ] Use NetExec on the IP Range 
- [ ] Use responder to catch IP addresses

` Make sure you understand the ROLE of each host you find. Careful service enumeration is key.` 

## 2 User Enumeration
### With foothold
- [ ] Get user list via SMB

###  Without foothold
- [ ] Attempt to get user list via SMB Null Authentication
- [ ] Attempt to get user list via LDAP Anonymous Bind
- [ ] Attempt to get user list via RPCClient
- [ ] Attempt to get user list via RID brute-forcing
- [ ] Attempt to get user list via Kerbruting

`No one of these techniques are guaranteed to discover all users. At least try the SMB, LDAP, RPCClient and RID methods.`

## 3 Get Foothold
- [ ] Find Kerberoastable users from the user list
- [ ] Find ASREPRoastable users from the users list
- [ ] User Responder to catch credential hashes
- [ ] Try SMB Null Authentication to pillage SMB shares looking for credentials
- [ ] Get `System / root` on Domain connected host to get a computer account
- [ ] Try password spraying with the user list 

`Avoid password spraying until you know what the domain password policy is! Lockouts can really ruin peoples day.`

## 4 Attacks
- [ ]  Use SharpHound to collect data to feed BloodHound
- [ ] Check compromised hosts on BloodHound for outbound attack paths
- [ ] Use NetExec to check for command execution via SMB, WinRM, and RDP for each compromised user
- [ ] Kerberoast
- [ ] ASREPRoast
- [ ] Look for credentials in GPOs (`gpp_password`, `autologin`)
- [ ] For each compromised user, pillage readable SMB shares for sensitive information
- [ ] For each compromised user, conduct SMB Hash Theft attacks on writable SMB shares
- [ ] Look for passwords in user's description fields
- [ ] Check the DC's SYSVOL SMB share for scripts containing credentials
- [ ] NoPac
- [ ] PrintNightmare
- [ ] PetitPotam
- [ ] Try compromised local administrator hashes on other hosts
- [ ] Try Responder on different hosts
- [ ] Look for users with the `PASSWD_NOTREQD` field
- [ ] Password spray using previously found passwords (spray, baby, spray)