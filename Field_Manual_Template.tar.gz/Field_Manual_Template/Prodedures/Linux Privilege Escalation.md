## Global

- [ ] Identify the Linux DIstro and Kernel version
- [ ] Check for credentials in web application config files
- [ ] Check interesting directories (`/opt`, `/var/mail`, etc.)
- [ ] Check capabilities
- [ ] Check if `sudo` version is vulnerable ([CVE-2023-22809](https://github.com/n3m1sys/CVE-2023-22809-sudoedit-privesc))
- [ ] Internal Nmap scan
- [ ] Check PwnKit
- [ ] Check LogRotate
- [ ] Monitor processes, look for anything interesting.
- [ ] Look for writable Docker socket files
- [ ] Look for Tmux sessions that can be hijacked.
- [ ] Check for NFS shares with `no_root_squash` enabled
- [ ] Check kernal exploits (e.g. [DirtyCow](https://github.com/firefart/dirtycow), [DirtyPipe](https://github.com/AlexisAhmed/CVE-2022-0847-DirtyPipe-Exploits))
- [ ] Listen for traffic using TcpDump. Cleartext creds?

## Per User

- [ ] Check which groups user belongs to
- [ ] Check sudo rights
- [ ] Check for environment variables
- [ ] Look for SSH keys on home directory
- [ ] Check for hidden files in home directory
- [ ] Check history files on home directory
- [ ] Enumerate SUID / GUID binaries
- [ ] Check `cronjobs` 
- [ ] Can we read other user's home directories?
- [ ] Check for password reuse with other users.
- [ ] Run `linpeas.sh`